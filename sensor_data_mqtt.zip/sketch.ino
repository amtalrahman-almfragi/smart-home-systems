#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>

// =========================
// WiFi (Wokwi)
// =========================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// =========================
// EMQX (TLS)
// =========================
const char* mqtt_server = "he1ad651.ala.eu-central-1.emqxsl.com";
const int mqtt_port = 8883;

const char* mqtt_user = "smart_home_user";
const char* mqtt_pass = "12345678";

// =========================
// Topics
// =========================
const char* topic_test     = "home/amona/test";
const char* topic_control  = "home/amona/control";
const char* topic_temp     = "home/amona/temperature";
const char* topic_humidity = "home/amona/humidity";
const char* topic_motion   = "home/amona/motion";
const char* topic_light    = "home/amona/light";
const char* topic_door     = "home/amona/door";

// =========================
// Sensor Pins
// =========================
#define DHTPIN     4
#define DHTTYPE    DHT22

#define PIR_PIN    13
#define LDR_PIN    34
#define DOOR_PIN   14

// =========================
// Objects
// =========================
WiFiClientSecure espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);

// This flag resets after every (re)subscribe to ignore retained control message
bool firstControlMessageIgnored = false;

// =========================
// MQTT Callback
// =========================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived on topic: ");
  Serial.println(topic);

  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("Message: ");
  Serial.println(message);

  // Ignore the first control message after each (re)subscribe (retained)
  if (String(topic) == topic_control && !firstControlMessageIgnored) {
    firstControlMessageIgnored = true;
    Serial.println("Retained control message ignored after (re)subscribe.");
    Serial.println("-----------------------");
    return;
  }

  if (message == "ON") {
    Serial.println("Light Turned ON");
  } else if (message == "OFF") {
    Serial.println("Light Turned OFF");
  } else {
    Serial.println("Unknown command (expected ON/OFF)");
  }

  Serial.println("-----------------------");
}

// =========================
// Connect MQTT
// =========================
bool connectMQTT() {
  Serial.print("Connecting to MQTT... ");

  String clientId = "ESP32-" + String((uint32_t)ESP.getEfuseMac(), HEX);

  if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
    Serial.println("Connected!");

    // Reset ignore flag after each successful connection
    firstControlMessageIgnored = false;

    // Subscribe only to control topic
    bool ok = client.subscribe(topic_control);
    Serial.print("Subscribe ");
    Serial.print(topic_control);
    Serial.print(" = ");
    Serial.println(ok ? "OK" : "FAILED");

    return true;
  }

  Serial.print("Failed, rc=");
  Serial.println(client.state());
  return false;
}

// =========================
// Setup
// =========================
void setup() {
  Serial.begin(115200);

  // Sensor pin modes
  pinMode(PIR_PIN, INPUT);
  pinMode(DOOR_PIN, INPUT_PULLUP);   // door sensor usually works well with pull-up
  pinMode(LDR_PIN, INPUT);

  dht.begin();

  // WiFi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");

  // TLS (for testing)
  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  // Connect MQTT
  while (!connectMQTT()) {
    delay(2000);
  }
}

// =========================
// Loop
// =========================
void loop() {
  // Reconnect if disconnected
  if (!client.connected()) {
    Serial.println("MQTT disconnected! Reconnecting...");
    while (!connectMQTT()) {
      delay(2000);
    }
  }

  client.loop();

  // Publish sensor data every 5 seconds
  static unsigned long lastMsg = 0;
  if (millis() - lastMsg > 5000) {
    lastMsg = millis();

    // ===== Read DHT22 =====
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();

    // ===== Read PIR =====
    int motionValue = digitalRead(PIR_PIN);   // 0 or 1

    // ===== Read LDR =====
    int lightValue = analogRead(LDR_PIN);     // 0 - 4095

    // ===== Read Door Sensor =====
    int doorValue = digitalRead(DOOR_PIN);    // with INPUT_PULLUP
    // LOW  = door open
    // HIGH = door closed

    // ===== Buffers =====
    char tempString[10];
    char humString[10];
    char motionString[10];
    char lightString[10];
    char doorString[10];

    // ===== Publish DHT if valid =====
    if (!isnan(temperature) && !isnan(humidity)) {
      dtostrf(temperature, 1, 2, tempString);
      dtostrf(humidity, 1, 2, humString);

      client.publish(topic_temp, tempString);
      client.publish(topic_humidity, humString);

      Serial.print("Temperature published: ");
      Serial.println(tempString);

      Serial.print("Humidity published: ");
      Serial.println(humString);
    } else {
      Serial.println("Failed to read from DHT sensor!");
    }

    // ===== Publish Motion =====
    if (motionValue == HIGH) {
      strcpy(motionString, "MOTION_DETECTED");
    } else {
      strcpy(motionString, "NO_MOTION");
    }
    client.publish(topic_motion, motionString);

    Serial.print("Motion published: ");
    Serial.println(motionString);

    // ===== Publish Light =====
    snprintf(lightString, sizeof(lightString), "%d", lightValue);
    client.publish(topic_light, lightString);

    Serial.print("Light published: ");
    Serial.println(lightString);

    // ===== Publish Door =====
    if (doorValue == LOW) {
      strcpy(doorString, "OPEN");
    } else {
      strcpy(doorString, "CLOSED");
    }
    client.publish(topic_door, doorString);

    Serial.print("Door published: ");
    Serial.println(doorString);

    // ===== Optional test message =====
    client.publish(topic_test, "ESP32 sensor data sent successfully");
    Serial.println("Published: ESP32 sensor data sent successfully");
    Serial.println("-----------------------");
  }
}