using UnityEngine;
using System.Collections;

public class FireSystem : MonoBehaviour
{
    [Header("Fire Effects")]
    public GameObject[] fireEffects;

    [Header("Sprinkler Effects")]
    public GameObject[] sprinklerEffects;

    [Header("Sprinkler Sound")]
    public AudioSource sprinklerAudio;

    [Header("Timing")]
    public float sprinklerDelay = 2f;
    public float extinguishDelay = 5f;

    private bool isRunning = false;

    void Start()
    {
        SetObjectsActive(fireEffects, false);
        SetObjectsActive(sprinklerEffects, false);

        if (sprinklerAudio != null)
        {
            sprinklerAudio.Stop();
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && !isRunning)
        {
            StartCoroutine(FireScenario());
        }
    }

    IEnumerator FireScenario()
    {
        isRunning = true;

        SetObjectsActive(fireEffects, true);
        Debug.Log("Fire Detected!");

        yield return new WaitForSeconds(sprinklerDelay);

        SetObjectsActive(sprinklerEffects, true);

        if (sprinklerAudio != null && !sprinklerAudio.isPlaying)
        {
            sprinklerAudio.Play();
        }

        Debug.Log("Sprinklers Activated!");

        yield return new WaitForSeconds(extinguishDelay);

        SetObjectsActive(fireEffects, false);
        Debug.Log("Fire Extinguished!");

        yield return new WaitForSeconds(2f);

        SetObjectsActive(sprinklerEffects, false);

        if (sprinklerAudio != null && sprinklerAudio.isPlaying)
        {
            sprinklerAudio.Stop();
        }

        Debug.Log("Sprinklers Stopped!");

        isRunning = false;
    }

    void SetObjectsActive(GameObject[] objects, bool state)
    {
        foreach (GameObject obj in objects)
        {
            if (obj != null)
            {
                obj.SetActive(state);
            }
        }
    }
}