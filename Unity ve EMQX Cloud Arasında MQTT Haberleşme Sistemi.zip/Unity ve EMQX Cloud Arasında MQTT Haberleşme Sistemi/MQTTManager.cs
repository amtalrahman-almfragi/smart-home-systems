using UnityEngine;
using uPLibrary.Networking.M2Mqtt;
using System;
using System.Text;

public class MQTTManager : MonoBehaviour
{
    public static MQTTManager Instance;

    [Header("MQTT Settings")]
    public string brokerAddress = "he1ad651.ala.eu-central-1.emqxsl.com";
    public int brokerPort = 8883;
    public string username = "smart_home_user";
    public string password = "12345678";

    private MqttClient client;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        try
        {
            client = new MqttClient(brokerAddress, brokerPort, true, null, null, MqttSslProtocols.TLSv1_2);

            string clientId = "UnityClient-" + System.Guid.NewGuid().ToString();
            client.Connect(clientId, username, password);

            if (client.IsConnected)
            {
                Debug.Log("MQTT Connected!");
                PublishMessage("home/amona/test", "Hello from Unity");
            }
            else
            {
                Debug.Log("MQTT Failed!");
            }
        }
        catch (Exception e)
        {
            Debug.LogError("MQTT Error: " + e.Message);
        }
    }

    public void PublishMessage(string topic, string message)
    {
        if (client != null && client.IsConnected)
        {
            client.Publish(topic, Encoding.UTF8.GetBytes(message), 0, true);
            Debug.Log("Sent: " + message + " to " + topic);
        }
        else
        {
            Debug.LogWarning("MQTT client is not connected.");
        }
    }

    void OnApplicationQuit()
    {
        if (client != null && client.IsConnected)
        {
            client.Disconnect();
            Debug.Log("MQTT Disconnected.");
        }
    }
}