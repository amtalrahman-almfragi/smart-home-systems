using UnityEngine;
using TMPro;
using System.Collections;

public class SmartLockPassword : MonoBehaviour
{
    public float relockDelay = 3f;

    [Header("UI References")]
    public TMP_InputField passwordInput;
    public TextMeshProUGUI messageText;
    public GameObject keypadPanel;
    public GameObject interactText;

    [Header("Trigger Reference")]
    public GameObject lockTrigger;

    [Header("Password Settings")]
    public string correctPassword = "1234";
    private int wrongAttempts = 0;
    public int maxWrongAttempts = 3;

    [Header("Player Teleport")]
    public Transform player;
    public Transform insidePoint;

    [Header("Alarm Sound")]
    public AudioSource alarmAudio;

    public void ActivateInput()
    {
        if (passwordInput != null)
        {
            passwordInput.text = "";
            passwordInput.ActivateInputField();
            passwordInput.Select();
        }
    }

    public void CheckPassword()
    {
        string enteredPassword = passwordInput.text;

        if (enteredPassword == correctPassword)
        {
            messageText.text = "Door Unlocked";

           
            if (alarmAudio != null && alarmAudio.isPlaying)
            {
                alarmAudio.Stop();
            }

            if (MQTTManager.Instance != null)
            {
                MQTTManager.Instance.PublishMessage("home/amona/door/lock/control", "UNLOCK");
                StartCoroutine(RelockDoorAfterDelay());
            }

            wrongAttempts = 0;

            if (player != null && insidePoint != null)
            {
                CharacterController cc = player.GetComponent<CharacterController>();

                if (cc != null)
                {
                    cc.enabled = false;
                    player.position = insidePoint.position;
                    player.rotation = insidePoint.rotation;
                    cc.enabled = true;
                }
                else
                {
                    player.position = insidePoint.position;
                    player.rotation = insidePoint.rotation;
                }
            }

            if (keypadPanel != null)
            {
                keypadPanel.SetActive(false);
            }

            if (interactText != null)
            {
                interactText.SetActive(false);
            }

            if (lockTrigger != null)
            {
                lockTrigger.SetActive(false);
            }

            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
        else
        {
            wrongAttempts++;
            messageText.text = "Wrong Password";

            if (wrongAttempts >= maxWrongAttempts)
            {
                messageText.text = "Alarm Activated!";

                
                if (alarmAudio != null && !alarmAudio.isPlaying)
                {
                    alarmAudio.Play();
                }

                if (MQTTManager.Instance != null)
                {
                    MQTTManager.Instance.PublishMessage("home/amona/alarm/control", "ALARM");
                }
            }
        }

        passwordInput.text = "";
        passwordInput.ActivateInputField();
    }

    public void CloseKeypad()
    {
        if (keypadPanel != null)
        {
            keypadPanel.SetActive(false);
        }

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private IEnumerator RelockDoorAfterDelay()
    {
        yield return new WaitForSeconds(relockDelay);

        if (MQTTManager.Instance != null)
        {
            MQTTManager.Instance.PublishMessage("home/amona/door/lock/control", "LOCK");
        }
    }
}