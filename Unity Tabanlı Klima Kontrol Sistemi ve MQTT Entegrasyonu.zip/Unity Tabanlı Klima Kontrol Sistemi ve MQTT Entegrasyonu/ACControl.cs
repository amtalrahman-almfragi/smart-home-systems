using UnityEngine;

public class ACControl : MonoBehaviour
{
    [Header("Sound")]
    public AudioSource acSound;

    private bool acOn = false;

    void Start()
    {
        if (acSound != null)
        {
            acSound.Stop();
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            ToggleAC();
        }
    }

    public void ToggleAC()
    {
        acOn = !acOn;

        // Sound Control
        if (acSound != null)
        {
            if (acOn)
            {
                acSound.Play();
            }
            else
            {
                acSound.Stop();
            }
        }

        // MQTT Control
        if (MQTTManager.Instance != null)
        {
            if (acOn)
            {
                MQTTManager.Instance.PublishMessage("home/amona/fan/control", "ON");
                Debug.Log("AC ON");
            }
            else
            {
                MQTTManager.Instance.PublishMessage("home/amona/fan/control", "OFF");
                Debug.Log("AC OFF");
            }
        }
    }
}