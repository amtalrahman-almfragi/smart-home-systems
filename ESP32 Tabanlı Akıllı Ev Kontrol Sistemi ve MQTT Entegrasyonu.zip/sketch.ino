#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ESP32Servo.h>

// =========================
// WiFi (Wokwi)
// =========================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// =========================
// EMQX (TLS)
// =========================
const char* mqtt_server = "he1ad651.ala.eu-central-1.emqxsl.com";
const int mqtt_port = 8883;

const char* mqtt_user = "smart_home_user";
const char* mqtt_pass = "12345678";

// =========================
// Topics
// =========================
const char* topic_test     = "home/amona/test";
const char* topic_temp     = "home/amona/temperature";
const char* topic_humidity = "home/amona/humidity";
const char* topic_motion   = "home/amona/motion";
const char* topic_light    = "home/amona/light";

const char* topic_light_control     = "home/amona/light/control";
const char* topic_fan_control       = "home/amona/fan/control";
const char* topic_alarm_control     = "home/amona/alarm/control";
const char* topic_door_lock_control = "home/amona/door/lock/control";

// =========================
// Pins
// =========================
#define DHTPIN     4
#define DHTTYPE    DHT22

#define PIR_PIN    13
#define LDR_PIN    34

#define LIGHT_PIN 27
#define FAN_PIN   26
#define ALARM_PIN 25
#define DOOR_LOCK_PIN 33
#define SPRINKLER_PIN 32

// =========================
// Objects
// =========================
WiFiClientSecure espClient;
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);
Servo doorLockServo;

// =========================
// Flags
// =========================
bool mqttAlarmActive = false;

// =========================
// MQTT Callback
// =========================
void callback(char* topic, byte* payload, unsigned int length) {
  Serial.println();
  Serial.print("Message arrived on topic: ");
  Serial.println(topic);

  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("Message: ");
  Serial.println(message);

  // Light Control
  if (String(topic) == topic_light_control) {
    if (message == "ON") {
      digitalWrite(LIGHT_PIN, HIGH);
      Serial.println("Light ON");
    }
    else if (message == "OFF") {
      digitalWrite(LIGHT_PIN, LOW);
      Serial.println("Light OFF");
    }
  }

  // Fan / AC Control
  if (String(topic) == topic_fan_control) {
    if (message == "ON") {
      digitalWrite(FAN_PIN, HIGH);
      Serial.println("Fan / AC ON");
    }
    else if (message == "OFF") {
      digitalWrite(FAN_PIN, LOW);
      Serial.println("Fan / AC OFF");
    }
  }

  // Alarm Control
  if (String(topic) == topic_alarm_control) {
    if (message == "ON" || message == "ALARM") {
      mqttAlarmActive = true;
      digitalWrite(ALARM_PIN, HIGH);
      Serial.println("Alarm ON / ALARM ACTIVATED");
    }
    else if (message == "OFF") {
      mqttAlarmActive = false;
      digitalWrite(ALARM_PIN, LOW);
      Serial.println("Alarm OFF");
    }
  }

  // Door Lock Control
  if (String(topic) == topic_door_lock_control) {
    if (message == "LOCK") {
      doorLockServo.write(0);
      Serial.println("Door LOCKED");
    }
    else if (message == "UNLOCK" || message == "OPEN") {
      doorLockServo.write(180);
      Serial.println("Door UNLOCKED");
    }
  }

  Serial.println("-----------------------");
}

// =========================
// Connect MQTT
// =========================
bool connectMQTT() {
  Serial.print("Connecting to MQTT... ");

  String clientId = "ESP32-" + String((uint32_t)ESP.getEfuseMac(), HEX);

  if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
    Serial.println("Connected!");

    client.subscribe(topic_light_control);
    client.subscribe(topic_fan_control);
    client.subscribe(topic_alarm_control);
    client.subscribe(topic_door_lock_control);

    Serial.println("Subscribed to control topics");
    Serial.println("-----------------------");

    return true;
  }

  Serial.print("Failed, rc=");
  Serial.println(client.state());
  return false;
}

// =========================
// Setup
// =========================
void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);

  pinMode(LIGHT_PIN, OUTPUT);
  pinMode(FAN_PIN, OUTPUT);
  pinMode(ALARM_PIN, OUTPUT);
  pinMode(SPRINKLER_PIN, OUTPUT);

  digitalWrite(LIGHT_PIN, LOW);
  digitalWrite(FAN_PIN, LOW);
  digitalWrite(ALARM_PIN, LOW);
  digitalWrite(SPRINKLER_PIN, LOW);

  dht.begin();

  doorLockServo.setPeriodHertz(50);
  doorLockServo.attach(DOOR_LOCK_PIN, 500, 2400);
  doorLockServo.write(0);   // Door starts locked

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected");

  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  while (!connectMQTT()) {
    delay(2000);
  }
}

// =========================
// Loop
// =========================
void loop() {
  if (!client.connected()) {
    Serial.println("MQTT disconnected! Reconnecting...");
    while (!connectMQTT()) {
      delay(2000);
    }
  }

  client.loop();

  static unsigned long lastMsg = 0;

  if (millis() - lastMsg > 5000) {
    lastMsg = millis();

    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();

    int motionValue = digitalRead(PIR_PIN);
    int lightValue = analogRead(LDR_PIN);

    char tempString[10];
    char humString[10];
    char motionString[25];
    char lightString[10];

    // Motion automation
    if (motionValue == HIGH) {
      digitalWrite(ALARM_PIN, HIGH);
      Serial.println("Automation: Motion detected -> Alarm ON");
    }
    else if (!mqttAlarmActive) {
      digitalWrite(ALARM_PIN, LOW);
    }

    // Fire automation
    if (!isnan(temperature) && temperature > 45) {
      digitalWrite(SPRINKLER_PIN, HIGH);
      Serial.println("Fire detected -> Sprinkler ON");
    }
    else {
      digitalWrite(SPRINKLER_PIN, LOW);
    }

    // Publish temperature and humidity
    if (!isnan(temperature) && !isnan(humidity)) {
      dtostrf(temperature, 1, 2, tempString);
      dtostrf(humidity, 1, 2, humString);

      client.publish(topic_temp, tempString);
      client.publish(topic_humidity, humString);

      Serial.print("Temperature published: ");
      Serial.println(tempString);

      Serial.print("Humidity published: ");
      Serial.println(humString);
    }
    else {
      Serial.println("Failed to read from DHT sensor!");
    }

    // Publish motion
    if (motionValue == HIGH) {
      strcpy(motionString, "MOTION_DETECTED");
    }
    else {
      strcpy(motionString, "NO_MOTION");
    }

    client.publish(topic_motion, motionString);
    Serial.print("Motion published: ");
    Serial.println(motionString);

    // Publish light value
    snprintf(lightString, sizeof(lightString), "%d", lightValue);
    client.publish(topic_light, lightString);

    Serial.print("Light published: ");
    Serial.println(lightString);

    // Test message
    client.publish(topic_test, "ESP32 sensor data sent successfully");
    Serial.println("Published: ESP32 sensor data sent successfully");
    Serial.println("-----------------------");
  }
}