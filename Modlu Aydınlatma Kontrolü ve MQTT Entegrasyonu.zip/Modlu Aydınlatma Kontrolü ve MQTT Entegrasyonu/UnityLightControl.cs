using UnityEngine;
using TMPro;

public class UnityLightControl : MonoBehaviour
{
    [Header("Day Light / Sun")]
    public Light directionalLight;

    [Header("Night / Interior Lights")]
    public Light[] interiorLights;

    [Header("UI Optional")]
    public TextMeshProUGUI buttonText;

    void Start()
    {
        SetDayMode();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.D))
        {
            SetDayMode();
        }

        if (Input.GetKeyDown(KeyCode.N))
        {
            SetNightMode();
        }

        if (Input.GetKeyDown(KeyCode.L))
        {
            SetLightsOff();
        }
    }

    public void SetDayMode()
    {
        if (directionalLight != null)
        {
            directionalLight.enabled = true;
            directionalLight.intensity = 1.2f;
        }

        SetInteriorLights(false);

        SendLightMQTT("ON");

        UpdateUI("Day Mode");
    }

    public void SetNightMode()
    {
        if (directionalLight != null)
        {
            directionalLight.enabled = false;
        }

        SetInteriorLights(true);

        SendLightMQTT("ON");

        UpdateUI("Night Mode");
    }

    public void SetLightsOff()
    {
        if (directionalLight != null)
        {
            directionalLight.enabled = false;
        }

        SetInteriorLights(false);

        SendLightMQTT("OFF");

        UpdateUI("Lights Off");
    }

    private void SetInteriorLights(bool state)
    {
        foreach (Light light in interiorLights)
        {
            if (light != null)
            {
                light.enabled = state;
            }
        }
    }

    private void SendLightMQTT(string message)
    {
        if (MQTTManager.Instance != null)
        {
            MQTTManager.Instance.PublishMessage("home/amona/light/control", message);
        }
    }

    private void UpdateUI(string text)
    {
        if (buttonText != null)
        {
            buttonText.text = text;
        }
    }
}