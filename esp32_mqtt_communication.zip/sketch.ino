#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// WiFi (Wokwi)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// EMQX (TLS)
const char* mqtt_server = "he1ad651.ala.eu-central-1.emqxsl.com";
const int mqtt_port = 8883;

const char* mqtt_user = "smart_home_user";
const char* mqtt_pass = "12345678";

// Topics
const char* topic_test    = "home/amona/test";
const char* topic_control = "home/amona/control";

WiFiClientSecure espClient;
PubSubClient client(espClient);

// This flag resets after every (re)subscribe to ignore retained control message
bool firstControlMessageIgnored = false;

void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived on topic: ");
  Serial.println(topic);

  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  message.trim();
  message.toUpperCase();

  Serial.print("Message: ");
  Serial.println(message);

  // Ignore the first control message after each (re)subscribe (retained)
  if (String(topic) == topic_control && !firstControlMessageIgnored) {
    firstControlMessageIgnored = true;
    Serial.println("Retained control message ignored after (re)subscribe.");
    Serial.println("-----------------------");
    return;
  }

  if (message == "ON") {
    Serial.println("Light Turned ON");
  } else if (message == "OFF") {
    Serial.println("Light Turned OFF");
  } else {
    Serial.println("Unknown command (expected ON/OFF)");
  }

  Serial.println("-----------------------");
}

bool connectMQTT() {
  Serial.print("Connecting to MQTT... ");

  // Stable unique clientId (better than millis)
  String clientId = "ESP32-" + String((uint32_t)ESP.getEfuseMac(), HEX);

  if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
    Serial.println("Connected!");

    // IMPORTANT: reset ignore flag after each successful connection
    firstControlMessageIgnored = false;

    // Subscribe ONLY to control topic (no wildcard)
    bool ok = client.subscribe(topic_control);
    Serial.print("Subscribe ");
    Serial.print(topic_control);
    Serial.print(" = ");
    Serial.println(ok ? "OK" : "FAILED");

    return true;
  }

  Serial.print("Failed, rc=");
  Serial.println(client.state());
  return false;
}

void setup() {
  Serial.begin(115200);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");

  // TLS (for test only)
  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);

  // Connect MQTT (keep trying)
  while (!connectMQTT()) {
    delay(2000);
  }
}

void loop() {
  // Reconnect if disconnected
  if (!client.connected()) {
    Serial.println("MQTT disconnected! Reconnecting...");
    while (!connectMQTT()) {
      delay(2000);
    }
  }

  client.loop();

  // Publish every 3 seconds to test topic
  static unsigned long lastMsg = 0;
  if (millis() - lastMsg > 3000) {
    lastMsg = millis();
    client.publish(topic_test, "Hello from ESP32 (Wokwi)!");
    Serial.println("Published: Hello from ESP32 (Wokwi)!");
  }
}